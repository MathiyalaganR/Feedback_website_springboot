package com.example.feedbackapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackappApplication.class, args);
	}

}
