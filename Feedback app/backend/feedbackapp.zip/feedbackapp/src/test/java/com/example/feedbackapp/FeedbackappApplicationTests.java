package com.example.feedbackapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackappApplicationTests {

	@Test
	void contextLoads() {
	}

}
